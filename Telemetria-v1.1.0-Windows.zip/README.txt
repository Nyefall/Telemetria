========================================
  SISTEMA DE TELEMETRIA DE HARDWARE
========================================

ARQUIVOS:
  Telemetria.exe   - Executavel Unificado
  config.json      - Configuracao do Sender
  libs/            - DLLs do LibreHardwareMonitor

========================================
COMO USAR
========================================

1. Execute Telemetria.exe
2. Selecione o modo de operacao:
   
   [SENDER] PC Principal
      - Coleta sensores de hardware
      - Requer privilegios de Administrador
      - Fica na bandeja do sistema
   
   [RECEIVER] Dashboard
      - Exibe telemetria em tempo real
      - Pode rodar em qualquer dispositivo
      - Nao requer Admin

========================================
ATALHOS DO RECEIVER
========================================

  I       = Configurar IP/Porta do Sender
  T       = Alternar tema (escuro/claro)
  L       = Ativar/desativar log CSV
  G       = Mostrar/ocultar graficos
  F / F11 = Fullscreen
  Q / ESC = Sair

========================================
CONFIGURACAO
========================================

MODO AUTOMATICO (Broadcast):
  - Ambos na mesma rede local
  - Receiver detecta automaticamente
  - Nao precisa configurar IP

MODO MANUAL (IP Fixo):
  1. Pressione I no Receiver
  2. Selecione "Manual"
  3. Digite o IP do PC Sender
  4. Porta padrao: 5005

FORCAR INTERFACE DE REDE (Sender):
  1. Edite config.json
  2. Altere "bind_ip" para o IP local
     Ex: "bind_ip": "192.168.10.101"
  3. Reinicie o Telemetria

========================================
SENSORES MONITORADOS
========================================

CPU:  Uso, Temperatura, Voltagem, Clock, Potencia
GPU:  Carga, Temperatura, Clock, VRAM, Fan RPM
RAM:  Uso percentual, Usada/Total
Disk: Temperatura, Saude, Atividade, Throughput
Rede: Download/Upload, Ping

========================================
SOLUCAO DE PROBLEMAS
========================================

RECEIVER NAO CONECTA:
  1. Verifique se o Sender esta rodando
  2. Libere porta UDP 5005 no firewall
  3. Use modo Manual (tecla I)
  4. Verifique mesma rede local

SENSORES RETORNAM 0:
  1. Execute como Administrador
  2. Verifique libs/ presente

VPN ATIVA:
  1. Edite config.json
  2. Configure bind_ip = IP da Ethernet
  3. Reinicie

========================================
REQUISITOS
========================================

- Windows 10/11
- Porta UDP 5005 liberada
- Admin no Sender

========================================

v2.0 | github.com/Nyefall/Telemetria
